import 'package:ahlachat/view/widgets/LevelWidget.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../models/Usermodel.dart';
import '../../util/Dialogs.dart';
import '../../util/Localization.dart';
import '../../util/helperclass.dart';
import '../../util/images.dart';
import '../../util/styles.dart';
import '../../viewmodels/Room_Viewmodel/Room_Viewmodel.dart';

class UserInfoWidgets extends StatelessWidget {
  usermodel? UserDate;

  UserInfoWidgets({this.UserDate});

  @override
  Widget build(BuildContext context) {
    RoomViewmodel Room =
        Provider.of<RoomViewmodel>(context, listen: true);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              UserDate?.Flag ?? '',
              style: const TextStyle(
                fontSize: 25,
              ),
            ),
            const SizedBox(
              width: 10,
            ),
            Row(
              children: [
                Text(
                  Helper().CutName(
                    UserDate?.name ?? '',
                  ),
                  style: Namestyle.copyWith(
                    fontSize: 16,
                    color: Colors.black,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                const SizedBox(
                  width: 5,
                ),
                if (UserDate?.SuporrtedImage != null)
                  CachedNetworkImage(
                    imageUrl: UserDate?.SuporrtedImage ?? '',
                    height: 15,
                  ),
              ],
            ),
          ],
        ),
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            LevelWidget(
              Karisma: UserDate?.Karisma ?? 0,
            ),
            const SizedBox(
              width: 2,
            ),
            if (UserDate != null &&
                UserDate?.MyVip != null &&
                UserDate?.MyVip?.Vip?.vipicon != null)
              Row(
                children: [
                  const SizedBox(
                    width: 3,
                  ),
                  CachedNetworkImage(
                    imageUrl:
                        UserDate?.MyVip?.Vip?.vipicon ?? "",
                    height: 15,
                  ),
                ],
              ),
            if (UserDate?.Supporter == 1)
              Image.asset(
                Images.Supporter,
                height: 16,
              ),
            const SizedBox(
              width: 2,
            ),
            Image.asset(
              UserDate?.ginder == '0'
                  ? Images.sexman
                  : Images.sexwoman,
              height: 16,
            ),
          ],
        ),
        const SizedBox(
          height: 2,
        ),
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              UserDate?.Newid ??
                  UserDate?.myappid ??
                  "",
              style: style6.copyWith(
                color: Colors.grey,
                fontSize: 17,
                height: 1,
              ),
            ),
            const SizedBox(
              width: 5,
            ),
            InkWell(
              onTap: () {
                Clipboard.setData(
                  ClipboardData(
                    text: UserDate?.Newid ??
                        UserDate?.myappid ??
                        "",
                  ),
                );

                Dialogs().showtoast(
                  getLang(
                    context: context,
                    key: "Copied",
                  ),
                );
              },
              child: const Icon(
                Icons.copy_outlined,
                color: Colors.grey,
                size: 16,
              ),
            ),
            if (UserDate?.MyVip != null &&
                UserDate?.MyVip?.Vip?.vipicon != null)
              CachedNetworkImage(
                imageUrl:
                    UserDate?.MyVip?.Vip?.gif ?? "",
                height: 25,
              ),
          ],
        ),
        const SizedBox(
          height: 2,
        ),
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (UserDate?.MyFamil != null)
              if (UserDate?.MyFamil?.model != null)
                CachedNetworkImage(
                  imageUrl:
                      UserDate?.MyFamil?.model ?? '',
                  height: 16,
                ),
            if (UserDate?.Admin == 1)
              Image.asset(
                Images.Manager,
                height: 16,
              ),
            if (UserDate?.SuperAdmin == 1)
              Image.asset(
                Images.SuperManager,
                height: 16,
              ),
            if (UserDate?.Official == 1)
              Image.asset(
                Images.Official,
                height: 16,
              ),
            if (UserDate?.MoneyAgency == 1)
              Image.asset(
                Images.MoneyAgency,
                height: 16,
              ),
            if (UserDate?.CustomersService == 1)
              Image.asset(
                Images.CustomerService,
                height: 16,
              ),
            if (UserDate?.MemberAgency == 1)
              Image.asset(
                Images.ServicesAgency,
                height: 16,
              ),
            if (UserDate?.AgencyId != null)
              Image.asset(
                Images.Services,
                height: 16,
              ),
            if (UserDate?.Announcer == 1)
              Image.asset(
                Images.Announcer,
                height: 16,
              ),
            if (UserDate?.DB == 1)
              Image.asset(
                Images.DB,
                height: 16,
              ),
          ],
        ),
      ],
    );
  }
}
