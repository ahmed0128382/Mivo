
 abstract class RoomRepository {


}
