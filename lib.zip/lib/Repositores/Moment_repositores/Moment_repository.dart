
 abstract class MomentRepository {


}
