
abstract class ShopRepository {

}
